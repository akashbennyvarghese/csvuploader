# csvuploader

pip install -r requirements.txt

django-admin startproject csvuploader

cd csvuploader

python manage.py startapp api

python manage.py makemigrations

python manage.py migrate

python manage.py runserver